# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 04:16:17 2023

@author: cesar
"""

import os

# Función para cargar preguntas desde un archivo de texto
def cargar_preguntas(nombre_archivo):
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as archivo:
            preguntas = archivo.readlines()
            preguntas = [pregunta.strip().replace('¿', '').replace('Â', '') for pregunta in preguntas]
        return preguntas
    except FileNotFoundError:
        print("El archivo de preguntas no se encuentra.")
        return []

# Función para realizar preguntas al usuario y obtener respuestas
def hacer_preguntas(preguntas):
    respuestas = []
    for pregunta in preguntas:
        respuesta = ""
        while respuesta not in ['y', 'n']:
            pregunta_sin_signos = pregunta.replace('ñ', 'n')
            respuesta = input(f"{pregunta_sin_signos} (Responda 'y' o 'n'): ").lower()
            if respuesta == 'y':
                respuestas.append(1)
            elif respuesta == 'n':
                respuestas.append(0)
            else:
                print("Por favor, responda con 'y' o 'n'.")
    return respuestas

# Función para cargar las respuestas de un problema desde un archivo de texto
def cargar_respuestas_problema(archivo):
    try:
        with open(archivo, 'r') as file:
            respuestas = [int(line.strip()) for line in file.readlines()]
        return respuestas
    except FileNotFoundError:
        print(f"El archivo {archivo} no se encuentra.")
        return []

# Función para cargar la descripción de un problema desde un archivo de texto
def cargar_descripcion_problema(archivo):
    try:
        with open(archivo, 'r') as file:
            descripcion = file.read()
        return descripcion
    except FileNotFoundError:
        print(f"El archivo {archivo} no se encuentra.")
        return ""

# Función para cargar la solución de un problema desde un archivo de texto
def cargar_solucion_problema(archivo):
    try:
        with open(archivo, 'r') as file:
            solucion = file.read()
        return solucion
    except FileNotFoundError:
        print(f"El archivo {archivo} no se encuentra.")
        return ""

# Función para calcular la distancia de Hamming entre dos listas
def distancia_hamming(lista1, lista2):
    return sum(el1 != el2 for el1, el2 in zip(lista1, lista2))

# Función para encontrar el problema más parecido al del usuario
def encontrar_problema_mas_parecido(respuestas_usuario):
    problemas_archivos = {
        "Pantalla_tactil_intermitente_o_no_responde": "respuestas_1.txt",
        "Pantalla_rota_o_con_grietas": "respuestas_2.txt",
        "Bateria_con_problemas": "respuestas_3.txt",
    	"Sobrecalentamiento_del_dispositivo": "respuestas_4.txt",
    	"Problemas_de_carga_o_conector": "respuestas_5.txt",
    	"Problemas_de_audio": "respuestas_6.txt",
    	"Botones_fisicos_que_no_funcionan": "respuestas_7.txt",
    	"Problemas_con_la_camara_o_calidad_de_imagen": "respuestas_8.txt",
    	"Problemas_de_conexion_Wi-Fi-Bluetooth": "respuestas_9.txt",
    	"Problemas_de_microfono-altavoz_durante_llamadas": "respuestas_10.txt",
    	"Problemas_de_almacenamiento": "respuestas_11.txt",
    	"Sensores_que_no_funcionan": "respuestas_12.txt",
    	"Problemas_de_GPS_o_ubicacion": "respuestas_13.txt",
    	"Vibracion_o_motor_haptico_con_problemas": "respuestas_14.txt",
    	"Problemas_de_reconocimiento_Touch-Face_ID": "respuestas_15.txt",
    	"Lentitud_o_bajo_rendimiento_del_sistema": "respuestas_16.txt",
    	"Botones_atascados_o_con_problemas_fisicos": "respuestas_17.txt",
    	"Danos_por_agua_o_liquidos": "respuestas_18.txt",
        "Problemas_de_hardware_no_identificados": "respuestas_19.txt"        

    }

    descripciones_archivos = {
        "Pantalla_tactil_intermitente_o_no_responde": "1.txt",
        "Pantalla_rota_o_con_grietas": "2.txt",
        "Bateria_con_problemas": "3.txt",
    	"Sobrecalentamiento_del_dispositivo": "4.txt",
    	"Problemas_de_carga_o_conector": "5.txt",
    	"Problemas_de_audio": "6.txt",
    	"Botones_fisicos_que_no_funcionan": "7.txt",
    	"Problemas_con_la_camara_o_calidad_de_imagen": "8.txt",
    	"Problemas_de_conexion_Wi-Fi-Bluetooth": "9.txt",
    	"Problemas_de_microfono-altavoz_durante_llamadas": "10.txt",
    	"Problemas_de_almacenamiento": "11.txt",
    	"Sensores_que_no_funcionan": "12.txt",
    	"Problemas_de_GPS_o_ubicacion": "13.txt",
    	"Vibracion_o_motor_haptico_con_problemas": "14.txt",
    	"Problemas_de_reconocimiento_Touch-Face_ID": "15.txt",
    	"Lentitud_o_bajo_rendimiento_del_sistema": "16.txt",
    	"Botones_atascados_o_con_problemas_fisicos": "17.txt",
    	"Danos_por_agua_o_liquidos": "18.txt",
        "Problemas_de_hardware_no_identificados": "19.txt" 
    }

    soluciones_archivos = {
        "Pantalla_tactil_intermitente_o_no_responde": "1.txt",
        "Pantalla_rota_o_con_grietas": "2.txt",
        "Bateria_con_problemas": "3.txt",
    	"Sobrecalentamiento_del_dispositivo": "4.txt",
    	"Problemas_de_carga_o_conector": "5.txt",
    	"Problemas_de_audio": "6.txt",
    	"Botones_fisicos_que_no_funcionan": "7.txt",
    	"Problemas_con_la_camara_o_calidad_de_imagen": "8.txt",
    	"Problemas_de_conexion_Wi-Fi-Bluetooth": "9.txt",
    	"Problemas_de_microfono-altavoz_durante_llamadas": "10.txt",
    	"Problemas_de_almacenamiento": "11.txt",
    	"Sensores_que_no_funcionan": "12.txt",
    	"Problemas_de_GPS_o_ubicacion": "13.txt",
    	"Vibracion_o_motor_haptico_con_problemas": "14.txt",
    	"Problemas_de_reconocimiento_Touch-Face_ID": "15.txt",
    	"Lentitud_o_bajo_rendimiento_del_sistema": "16.txt",
    	"Botones_atascados_o_con_problemas_fisicos": "17.txt",
    	"Danos_por_agua_o_liquidos": "18.txt",
        "Problemas_de_hardware_no_identificados": "19.txt" 
    }

    mejor_coincidencia = float('inf')
    problema_mas_parecido = None

    for problema, archivo in problemas_archivos.items():
        if os.path.exists(archivo):
            respuestas_problema = cargar_respuestas_problema(archivo)
            if len(respuestas_usuario) == len(respuestas_problema):
                distancia = distancia_hamming(respuestas_usuario, respuestas_problema)
                if distancia < mejor_coincidencia:
                    mejor_coincidencia = distancia
                    problema_mas_parecido = problema

    if problema_mas_parecido:
        archivo_descripcion = descripciones_archivos.get(problema_mas_parecido)
        descripcion = cargar_descripcion_problema(f"Problemas_Descripcion/{archivo_descripcion}")

        archivo_solucion = soluciones_archivos.get(problema_mas_parecido)
        solucion = cargar_solucion_problema(f"Problemas_Solucion/{archivo_solucion}")

        if descripcion and solucion:
            print(f"El problema más parecido es: {problema_mas_parecido}")
            print(f"Descripción del problema:\n{descripcion}")
            print(f"Solución propuesta:\n{solucion}")

    return problema_mas_parecido

# Función principal del programa
def main():
    print("¡Bienvenido a iPhoneDoc!")
    print("iPhoneDoc es un sistema experto diseñado para ayudarte a diagnosticar problemas de hardware en tu dispositivo iPhone.")
    print("Responderás una serie de preguntas con 'y' o 'n', donde 'y' significa sí y 'n' significa no.")
    print("Las respuestas se guardarán en un archivo para tu referencia.")
    print("Comencemos con el diagnóstico.")

    archivo_preguntas = "Preguntas.txt"
    preguntas = cargar_preguntas(archivo_preguntas)

    if preguntas:
        while True:
            print("Por favor, responda las siguientes preguntas sobre su dispositivo iPhone.")
            respuestas = hacer_preguntas(preguntas)
            archivo_usuario = "Archivos_Usuarios/usuarioX.txt"

            with open(archivo_usuario, "w") as archivo_respuestas:
                for respuesta in respuestas:
                    archivo_respuestas.write(str(respuesta) + "\n")

                print(f"Las respuestas se han guardado correctamente en '{archivo_usuario}'.")

                problema_mas_parecido = encontrar_problema_mas_parecido(respuestas)
                if not problema_mas_parecido:
                    print("No se encontró un problema similar.")

                continuar = input("¿Desea responder las preguntas nuevamente? (Responda 'y' o 'n'): ").lower()
                if continuar != 'y':
                    break

        print("\n¡Gracias por utilizar iPhoneDoc!")

if __name__ == "__main__":
    main()
